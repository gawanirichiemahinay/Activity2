<?php
$name = $email = $address = $contact = "";
$nameErr = $emailErr = $contactErr = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $valid = true;

    // Name Validation
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
        $valid = false;
    } else {
        $name = test_input($_POST["name"]);
        if (!preg_match("/^[a-zA-Z Ññ ]*$/", $name)) {
            $nameErr = "Only letters and white space allowed";
            $valid = false;
        }
    }

    // Email Validation
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
        $valid = false;
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
            $valid = false;
        }
    }

    // Contact Validation
    if (empty($_POST["contact"])) {
        $contactErr = "Contact number is required";
        $valid = false;
    } else {
        $contact = test_input($_POST["contact"]);
        if (!preg_match("/^\d{11}$/", $contact)) {
            $contactErr = "Contact must be 11 digits";
            $valid = false;
        }
    }

    // Address (Optional)
    $address = test_input($_POST["address"]);

    if ($valid) {
        $success = true;
    }
}

function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP Form Validation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 10px;
            background-image: url("img/wawawin.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            align-items: center;
            justify-content: center;
        }
        .error { color: red; font-size: 14px; }
        label {
            display: block;
            margin-top: 15px;
        }
        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            box-sizing: border-box;
        }
        button {
            margin-top: 20px;
            padding: 10px 20px;
            background:rgb(70, 116, 230);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.5s;
        }
        button:hover{
            background-color:rgb(18, 63, 146);

        }
        .success {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
        }
        .header {
            width: 70vh;
            height: 25vh;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 25px;
        }
        .raffle{
            color: white;
            height: 60px;
            justify-content: center;
            text-shadow: 1px,1px,3px rgba(0, 0, 0, 0);
            right: 35%;
            bottom: 480px;
            position: absolute;
        }
        .pic1{
            width: auto;
            height: 55vh;
            position: absolute;
            left: 80%;
            bottom: 0%;
        }
        .pic2{
            width: auto;
            height: 75vh;
            position: absolute;
            right: 75%;

        }

    </style>
</head>
<body>
<div>
    <img class="header" src="img/wowowin.png">
    <h1 class="raffle"></h1>
    <img class="pic1" src="img/willie 1.svg">
    <img class="pic2" src="img/willie 2.svg">
</div>
<div class="container">
    <h2>Registration Form</h2>
    <?php
    if (!$success && $_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["name"]) && empty($_POST["email"]) && empty($_POST["contact"])) {
        echo '<div class="error">Please fill in all required fields.</div>';
    }
    ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Name *</label>
        <input type="text" name="name" value="<?php echo $name; ?>">
        <span class="error"><?php echo $nameErr; ?></span>

        <label for="email">Email *</label>
        <input type="text" name="email" value="<?php echo $email; ?>">
        <span class="error"><?php echo $emailErr; ?></span>

        <label for="contact">Contact Number *</label>
        <input type="text" name="contact" value="<?php echo $contact; ?>">
        <span class="error"><?php echo $contactErr; ?></span>

        <label for="address">Address (Optional)</label>
        <input type="text" name="address" value="<?php echo $address; ?>">

        <button type="submit">Submit</button>

        
    </form>
    
    <?php if ($success): ?>
        <div class="success">
            <h3>Raffle Entry Submitted Successfully</h3>
            <p><strong>Name:</strong> <?php echo $name; ?></p>
            <p><strong>Email:</strong> <?php echo $email; ?></p>
            <p><strong>Contact:</strong> <?php echo $contact; ?></p>
            <p><strong>Address:</strong> <?php echo $address ?: 'N/A'; ?></p>
        </div>
    <?php endif; ?>
    
</div>
<audio autoplay loop controls>
        <source src="img/wowowin.mp3" type="audio/mpeg">
        Your browser does not support the audio tag.
    </audio>
</body>
</html>
